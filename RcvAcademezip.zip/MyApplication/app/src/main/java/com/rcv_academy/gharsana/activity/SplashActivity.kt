package com.rcv_academy.gharsana.activity


import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.rcv_academy.gharsana.R
import com.rcv_academy.gharsana.viewmodel.SplashViewModel


class SplashActivity: AppCompatActivity(){

lateinit var splashViewModel: SplashViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        splashViewModel = ViewModelProviders.of(this).get(SplashViewModel::class.java)

        splashViewModel.getSplashRemote()?.observe(this, Observer {

            if (it!!){

                startActivity(Intent(this,LoginActivity::class.java))
                finish()
            }

        })
    }
}