package com.rcv_academy.gharsana.viewmodel


import android.content.Context
import android.os.Handler
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SplashViewModel : ViewModel(){
    private var mCanShowNext: MutableLiveData<Boolean>? = null

    init {
        mCanShowNext = MutableLiveData()
        mCanShowNext!!.value = false

        Handler().postDelayed({ mCanShowNext!!.postValue(true) }, 1800)
    }

    fun getSplashRemote(): LiveData<Boolean?>? {
        return mCanShowNext
    }

    fun displayToast(context: Context?, msz: String?) {
        Toast.makeText(context, msz, Toast.LENGTH_SHORT).show()
    }

}