package com.rcv_academy.gharsana.adaptor

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.rcv_academy.gharsana.R
import com.rcv_academy.gharsana.model.question.QuestionsList
import de.hdodenhof.circleimageview.CircleImageView

class HomeScreenAdaptor  : BaseAdapter {
    lateinit var courseList:ArrayList<String>
    lateinit var context: Context
    lateinit var inflater: LayoutInflater

    constructor(questionList: ArrayList<String>, context: Context) : super() {
        this.courseList = questionList
        this.context = context
        inflater = LayoutInflater.from(context)
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var curruntCourse = courseList.get(p0)
        var myView = inflater.inflate(R.layout.home_screen_item, null)
        var txtCourseName: TextView = myView.findViewById(R.id.txtCourseName)


        txtCourseName.text=curruntCourse

        return myView;

    }

    override fun getItem(p0: Int): Any {
        return 0
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getCount(): Int {
        return courseList.size
    }

}