package com.rcv_academy.gharsana.model.question;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SectionDetail {

    @SerializedName("sectionName")
    @Expose
    private String sectionName;
    @SerializedName("maxMarks")
    @Expose
    private String maxMarks;

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public String getMaxMarks() {
        return maxMarks;
    }

    public void setMaxMarks(String maxMarks) {
        this.maxMarks = maxMarks;
    }

}