package com.rcv_academy.gharsana.utill;

public class PublicValues {

    public static final String QUESTION_KEY = "QuestionJson";
    public static final String PREFERENCE_KEY = "QuestionData";


}
