package com.rcv_academy.gharsana.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.rcv_academy.gharsana.R
import com.rcv_academy.gharsana.quiz.QuestionScreenActivity
import com.rcv_academy.gharsana.utill.Common
import org.json.JSONException


class InstructionActivity : AppCompatActivity() {
    private var requestQueue: RequestQueue? = null
    lateinit var progressBar: ProgressBar
    lateinit var buttonOk:Button
    lateinit var common: Common
    var json = ""
    //    private var imageReference: StorageReference? = null
    //    private var fileRef : StorageReference? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.instruction_activity)
        common = Common(this)
        requestQueue = Volley.newRequestQueue(this)
        progressBar = findViewById(R.id.progress_circular)
        buttonOk = findViewById(R.id.buttonOk)
    }

    fun instructionOkClick(view: View) {
       // val gsReference = storage.getReferenceFromUrl("gs://bucket/images/stars.jpg")

//        var json = "{\n" +
//                "   \"durationMinute\": \"10\",\n" +
//                "   \"totalQuestions\": \"10\",\n" +
//                "   \"maxMarks\": \"200\",\n" +
//                "   \"eachQuesMark\": \"20\",\n" +
//                "   \"section\": \"3\",\n" +
//                "   \"sectionDetails\": [\n" +
//                "      {\n" +
//                "         \"sectionName\": \"Reasoning\",\n" +
//                "         \"maxMarks\": \"50\"\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"sectionName\": \"General Study\",\n" +
//                "         \"maxMarks\": \"50\"\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"sectionName\": \"English\",\n" +
//                "         \"maxMarks\": \"100\"\n" +
//                "      }\n" +
//                "   ],\n" +
//                "   \"questionsList\": [\n" +
//                "      {\n" +
//                "         \"id\": \"1\",\n" +
//                "         \"section\": \"1\",\n" +
//                "         \"question\": \"Hero in My name is khan movie\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"salmaan\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"shahrukh\",\n" +
//                "               \"isTrue\": true\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"kajol\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"Amitabh\",\n" +
//                "               \"isTrue\": false\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"2\",\n" +
//                "         \"section\": \"1\",\n" +
//                "         \"question\": \"who Host bigg boss from the following\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"Shahrukh\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"Akshay\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"Irfan\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"salmaan\",\n" +
//                "               \"isTrue\": true\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"3\",\n" +
//                "         \"section\": \"1\",\n" +
//                "         \"question\": \"Named the Beautiful city in india\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"Delhi\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"jaipur\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"chandigarh\",\n" +
//                "               \"isTrue\": true\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"Indore\",\n" +
//                "               \"isTrue\": true\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"4\",\n" +
//                "         \"section\": \"2\",\n" +
//                "         \"question\": \"which of the batchler degree take 5 years to complete\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"MBBS\",\n" +
//                "               \"isTrue\": true\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"BA\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"BCA\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"B.Pharma\",\n" +
//                "               \"isTrue\": false\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"5\",\n" +
//                "         \"section\": \"2\",\n" +
//                "         \"question\": \"Who Host KBC ?\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"Shilpa\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"Karan Johar\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"Krishama tanna\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"Amitabh\",\n" +
//                "               \"isTrue\": true\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"6\",\n" +
//                "         \"section\": \"2\",\n" +
//                "         \"question\": \"Best Comedian in india from following\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"Krushna Abhishek\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"Bharti Singh\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"Kapil Sharma\",\n" +
//                "               \"isTrue\": true\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"Chandan Parbhakar\",\n" +
//                "               \"isTrue\": false\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"7\",\n" +
//                "         \"section\": \"3\",\n" +
//                "         \"question\": \"Best Budget Car Brand in india?\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"Hyundai\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"Maruti-suzuki\",\n" +
//                "               \"isTrue\": true\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"BMW\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"WolksVagon\",\n" +
//                "               \"isTrue\": false\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"8\",\n" +
//                "         \"section\": \"3\",\n" +
//                "         \"question\": \"Best in Quality car Brand in india?\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"BMW\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"volvo\",\n" +
//                "               \"isTrue\": true\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"Audi\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"Land Rover\",\n" +
//                "               \"isTrue\": false\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"9\",\n" +
//                "         \"section\": \"3\",\n" +
//                "         \"question\": \"which one of the following car brand is not available in india?\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"Chevoralet\",\n" +
//                "               \"isTrue\": true\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"Volvo\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"Farari\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"BMW\",\n" +
//                "               \"isTrue\": false\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      },\n" +
//                "      {\n" +
//                "         \"id\": \"10\",\n" +
//                "         \"section\": \"3\",\n" +
//                "         \"question\": \"when was the corona first patient found?\",\n" +
//                "         \"optionsList\": [\n" +
//                "            {\n" +
//                "               \"id\": \"1\",\n" +
//                "               \"option\": \"01 Jan 2020\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"2\",\n" +
//                "               \"option\": \"01 Feb 2020\",\n" +
//                "               \"isTrue\": false\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"3\",\n" +
//                "               \"option\": \"31 Dec 2019\",\n" +
//                "               \"isTrue\": true\n" +
//                "            },\n" +
//                "            {\n" +
//                "               \"id\": \"4\",\n" +
//                "               \"option\": \"29 Feb 2020\",\n" +
//                "               \"isTrue\": false\n" +
//                "            }\n" +
//                "         ]\n" +
//                "      }\n" +
//                "   ]\n" +
//                "}"
//        val sharedPreference =  getSharedPreferences("QuestionData", Context.MODE_PRIVATE)
//        var editor = sharedPreference.edit()
//        editor.putString("QuestionJson",json)
//
//        editor.commit()
//        startActivity(Intent(this,QuestionScreenActivity::class.java))

//        var gson:Gson = Gson()
//        var pp = gson.fromJson(json,Questions::class.java)
        progressBar.visibility= View.VISIBLE
        buttonOk.visibility= View.INVISIBLE
        getUrlAsync();

    }

    private fun getUrlAsync() {
        // Points to the root reference
        val storageRef: StorageReference = FirebaseStorage.getInstance().getReference()
        val dateRef: StorageReference = storageRef.child("/LatestQuestion/QuestionariesSample.json")
        dateRef.getDownloadUrl().addOnSuccessListener(OnSuccessListener<Any?> {
            //do something with downloadurl
            jsonParse(it.toString())
        }).addOnFailureListener(OnFailureListener {
            Toast.makeText(this,it.message,Toast.LENGTH_LONG).show()
            progressBar.visibility = View.GONE
        })
    }

    private fun jsonParse(url:String) {
       // val url = "https://api.myjson.com/bins/xbspb"
        val request = JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {
            json = it.toString()
            common.saveJsonToPref(json)
            startActivity(Intent(this,QuestionScreenActivity::class.java))
            finish()
//                response ->try {
//            val jsonArray = response.getJSONArray("employees")
//            for (i in 0 until jsonArray.length()) {
//                val employee = jsonArray.getJSONObject(i)
//                val firstName = employee.getString("firstname")
//                val age = employee.getInt("age")
//                val mail = employee.getString("mail")
//               // textView.append("$firstName, $age, $mail\n\n")
//            }
//        } catch (e: JSONException) {
//            e.printStackTrace()
//        }
        }, Response.ErrorListener { error -> error.printStackTrace() })
        requestQueue?.add(request)
    }

}