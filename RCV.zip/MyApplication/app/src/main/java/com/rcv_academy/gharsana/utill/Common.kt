package com.rcv_academy.gharsana.utill

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.rcv_academy.gharsana.model.question.Questions

public class Common(context: Context){
   // lateinit var context: Context
   lateinit var gson:Gson
   lateinit var sharedPreference:SharedPreferences
    init {
        sharedPreference =context.getSharedPreferences(PublicValues.PREFERENCE_KEY, Context.MODE_PRIVATE)
        gson = Gson()
    }

    fun saveJsonToPref(jsonData: String){

        var editor = sharedPreference.edit()
        editor.putString(PublicValues.QUESTION_KEY,jsonData)
        editor.commit()

    }

    fun  getQuestionData() : Questions? {
        var questions: Questions? = null
        var questionJson = sharedPreference.getString(PublicValues.QUESTION_KEY,"")
        if (!questionJson.isNullOrEmpty()){
            questions= gson.fromJson(questionJson,Questions::class.java)
        }
        return questions
    }

}