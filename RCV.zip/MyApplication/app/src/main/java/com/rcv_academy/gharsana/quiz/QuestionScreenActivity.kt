package com.rcv_academy.gharsana.quiz

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.myapplication.adaptor.VideoGridAdaptor
import com.rcv_academy.gharsana.R
import com.rcv_academy.gharsana.model.question.QuestionsList
import com.rcv_academy.gharsana.utill.Common
import kotlinx.android.synthetic.main.activity_question_screen.*
import nl.dionsegijn.konfetti.models.Size


public class QuestionScreenActivity : AppCompatActivity(), View.OnClickListener {
    var START_MILLI_SECONDS = 60000L
    var milisUntilFinish:Long = 0;

    lateinit var sideNavView: LinearLayout
    lateinit var imgreview: ImageView
    lateinit var txtQuesNo: TextView
    lateinit var totalQues: TextView
    lateinit var countdown_timer: CountDownTimer
    var isRunning: Boolean = false;
    var time_in_milli_seconds = 0L
    lateinit var questTextview: TextView;
    lateinit var opt1text: TextView;
    lateinit var opt2text: TextView;
    lateinit var opt3text: TextView;
    lateinit var opt4text: TextView;

    lateinit var llopt1: LinearLayout
    lateinit var llopt2: LinearLayout
    lateinit var llopt3: LinearLayout
    lateinit var llopt4: LinearLayout
    lateinit var time_edit_text: TextView
    lateinit var gridView: GridView
    lateinit var videoGridAdaptor: VideoGridAdaptor
    var curruntQuesCount = 0;

    lateinit var questList: List<QuestionsList>
    lateinit var comonClass: Common

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_question_screen)
        initView()
        setQuestionView(curruntQuesCount)
        llopt1.setOnClickListener(this)
        llopt2.setOnClickListener(this)
        llopt3.setOnClickListener(this)
        llopt4.setOnClickListener(this)

    }

    private fun startTimer(time_in_seconds: Long) {
        countdown_timer = object : CountDownTimer(time_in_seconds, 1000) {
            override fun onFinish() {
                loadConfeti()
            }

            override fun onTick(p0: Long) {
                time_in_milli_seconds = p0
                updateTextUI()
            }
        }
        countdown_timer.start()

        isRunning = true
        //button.text = "Pause"
        //reset.visibility = View.INVISIBLE

    }

    private fun updateTextUI() {
        val minute = (time_in_milli_seconds / 1000) / 60
        val seconds = (time_in_milli_seconds / 1000) % 60

        time_edit_text.text = "$minute:$seconds"
    }

    private fun loadConfeti() {
        viewKonfetti.build()
            .addColors(Color.YELLOW, Color.GREEN, Color.MAGENTA)
            .setDirection(0.0, 359.0)
            .setSpeed(1f, 5f)
            .setFadeOutEnabled(true)
            .setTimeToLive(2000L)
            .addShapes(
                nl.dionsegijn.konfetti.models.Shape.RECT,
                nl.dionsegijn.konfetti.models.Shape.CIRCLE
            )
            .addSizes(Size(12))
            .setPosition(-50f, viewKonfetti.width + 50f, -50f, -50f)
            .streamFor(300, 5000L)
    }

    fun initView() {
        txtQuesNo = findViewById(R.id.txtQuesNo)
        totalQues = findViewById(R.id.totalQues)
        imgreview = findViewById(R.id.imgreview)
        gridView = findViewById(R.id.simpleGridView)
        time_edit_text = findViewById(R.id.time_edit_text)
        questTextview = findViewById(R.id.questtext)
        opt1text = findViewById(R.id.optText1)
        sideNavView = findViewById(R.id.sideNavView)
        opt2text = findViewById(R.id.optText2)
        opt3text = findViewById(R.id.optText3)
        opt4text = findViewById(R.id.optText4)

        llopt1 = findViewById(R.id.llopt1)
        llopt2 = findViewById(R.id.llopt2)
        llopt3 = findViewById(R.id.llopt3)
        llopt4 = findViewById(R.id.llopt4)


        comonClass = Common(this)
        var questionData = comonClass.getQuestionData()
        var timeDuration = questionData?.durationMinute

        if (timeDuration != null) {
            time_in_milli_seconds = timeDuration.toLong() * 60000L
            startTimer(time_in_milli_seconds)
        }

        questList = questionData?.questionsList as List<QuestionsList>
        videoGridAdaptor = VideoGridAdaptor(questList, this)
        gridView.adapter = videoGridAdaptor

        totalQues.text = questList.size.toString()
        gridView.setOnItemClickListener(AdapterView.OnItemClickListener { adapterView, view, i, l ->

            sideNavView.visibility = View.GONE
            curruntQuesCount = i
            setQuestionView(i)


        })

    }
    var ATTEMPTED : String = "attempted"
    var UNATTEMPTED : String = "unattempted"
    var REVIEW : String = "review"

    fun getQuesReport(questionsList: List<QuestionsList>): HashMap<String, Int> {
        var quesReport: HashMap<String, Int> = HashMap()
//        quesReport.put("attempted",0)
//        quesReport.put("unattempted",0)
//        quesReport.put("review",0)

        var attempted: Int = 0
        var unattempted: Int = 0
        var review: Int = 0

        for (item in questionsList) {

            if (item.userResponse == 1||item.userResponse == 0) {
                unattempted++
            } else if (item.userResponse == 2) {
                attempted++
            } else if (item.userResponse == 3) {
                review++
            }
        quesReport.put(ATTEMPTED,attempted)
        quesReport.put(UNATTEMPTED,unattempted)
        quesReport.put(REVIEW,review)
        }

        return  quesReport

    }

    fun setQuestionView(count: Int) {

        var curruntQuestData = questList.get(count)
        if (curruntQuestData.userResponse == 3) {
            imgreview.visibility = View.VISIBLE
        } else {
            imgreview.visibility = View.GONE
        }
        txtQuesNo.text = (count + 1).toString()

        questTextview.text = curruntQuestData.question
        opt1text.text = curruntQuestData.optionsList.get(0).option
        opt2text.text = curruntQuestData.optionsList.get(1).option
        opt3text.text = curruntQuestData.optionsList.get(2).option
        opt4text.text = curruntQuestData.optionsList.get(3).option


        when (curruntQuestData.answeredOption) {
            0 -> {
                llopt1.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt2.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt3.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt4.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
            1 -> {
                llopt1.background =
                    ContextCompat.getDrawable(this, R.drawable.selected_option_bsckground)
                llopt2.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt3.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt4.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
            2 -> {
                llopt2.background =
                    ContextCompat.getDrawable(this, R.drawable.selected_option_bsckground)
                llopt1.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt3.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt4.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
            3 -> {
                llopt3.background =
                    ContextCompat.getDrawable(this, R.drawable.selected_option_bsckground)
                llopt2.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt1.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt4.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
            4 -> {
                llopt4.background =
                    ContextCompat.getDrawable(this, R.drawable.selected_option_bsckground)
                llopt2.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt3.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt1.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
        }
        if (questList.get(count).userResponse == 0) {
            questList.get(count).userResponse = 1//visited
        }


    }

    fun setNextQuestion(view: View) {
        curruntQuesCount++
        if (curruntQuesCount < questList.size) {
            setQuestionView(curruntQuesCount)
        } else {
            curruntQuesCount = questList.size - 1
        }
    }

    fun setPreviousClick(view: View) {
        curruntQuesCount--
        if (curruntQuesCount >= 0) {
            setQuestionView(curruntQuesCount)
        } else {
            curruntQuesCount = 0
        }

    }

    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.llopt1 -> {
                questList.get(curruntQuesCount).answeredOption = 1
                if (!(questList.get(curruntQuesCount).userResponse == 3)) {
                    questList.get(curruntQuesCount).userResponse = 2//answered
                }


                llopt1.background =
                    ContextCompat.getDrawable(this, R.drawable.selected_option_bsckground)
                llopt2.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt3.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt4.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
            R.id.llopt2 -> {
                questList.get(curruntQuesCount).answeredOption = 2
                if (!(questList.get(curruntQuesCount).userResponse == 3)) {
                    questList.get(curruntQuesCount).userResponse = 2//answered
                }

                llopt2.background =
                    ContextCompat.getDrawable(this, R.drawable.selected_option_bsckground)
                llopt1.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt3.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt4.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
            R.id.llopt3 -> {
                questList.get(curruntQuesCount).answeredOption = 3
                if (!(questList.get(curruntQuesCount).userResponse == 3)) {
                    questList.get(curruntQuesCount).userResponse = 2//answered
                }

                llopt3.background =
                    ContextCompat.getDrawable(this, R.drawable.selected_option_bsckground)
                llopt2.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt1.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt4.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
            R.id.llopt4 -> {
                questList.get(curruntQuesCount).answeredOption = 4
                if (!(questList.get(curruntQuesCount).userResponse == 3)) {
                    questList.get(curruntQuesCount).userResponse = 2//answered
                }

                llopt4.background =
                    ContextCompat.getDrawable(this, R.drawable.selected_option_bsckground)
                llopt2.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt3.background = ContextCompat.getDrawable(this, R.drawable.option_background)
                llopt1.background = ContextCompat.getDrawable(this, R.drawable.option_background)
            }
        }
    }

    fun onSubmitClick(view: View) {
        val builder: AlertDialog.Builder = AlertDialog.Builder(this@QuestionScreenActivity)
        builder.setCancelable(false)
        val viewGroup = findViewById<ViewGroup>(R.id.content)
        val dialogView: View =
            LayoutInflater.from(this).inflate(R.layout.submit_question_view, viewGroup, false)

       var txtreview: TextView = dialogView.findViewById(R.id.txtreview)
       var txtAttempted: TextView = dialogView.findViewById(R.id.txtAttempted)
       var txtUnAttempted: TextView = dialogView.findViewById(R.id.txtUnAttempted)
       var txtTimeleft: TextView = dialogView.findViewById(R.id.txtTimeleft)
        var btnSubmitt :Button = dialogView.findViewById(R.id.btnSubmitt)
        var btnCancel :Button = dialogView.findViewById(R.id.btnCancel)


        var quesReport = getQuesReport(questList)
        val minute = (time_in_milli_seconds / 1000) / 60
        val seconds = (time_in_milli_seconds / 1000) % 60


        txtTimeleft.text = "$minute min,$seconds sec"

        txtAttempted.text = quesReport[ATTEMPTED].toString()
        txtUnAttempted.text = quesReport[UNATTEMPTED].toString()
        txtreview.text = quesReport[REVIEW].toString()
        builder.setView(dialogView)

        val alertDialog: AlertDialog = builder.create()
        alertDialog.show()
        btnCancel.setOnClickListener(View.OnClickListener {
            alertDialog.dismiss()
        })
        btnSubmitt.setOnClickListener(View.OnClickListener {

        })
//        val dialog = Dialog(this, R.style.AppTheme_NoActionBar)
//        dialog.requestWindowFeature(Window.FEATURE_ACTION_BAR)
//        dialog.setContentView(R.layout.submit_question_view)
//        dialog.show()
    }

    fun closeNavClick(view: View) {
        sideNavView.visibility = View.GONE
    }

    fun openSideNavClick(view: View) {
        videoGridAdaptor = VideoGridAdaptor(questList, this)
        gridView.adapter = videoGridAdaptor
        sideNavView.visibility = View.VISIBLE

    }

    fun onclickMarrkAsReview(view: View) {
        if (questList.get(curruntQuesCount).userResponse == 3) {
            if (questList.get(curruntQuesCount).answeredOption == 0) {
                questList.get(curruntQuesCount).userResponse = 1
            } else {
                questList.get(curruntQuesCount).userResponse = 2
            }
        } else {
            questList.get(curruntQuesCount).userResponse = 3
        }
        setQuestionView(curruntQuesCount)
    }

    fun onclickClearSelection(view: View) {
        questList.get(curruntQuesCount).answeredOption = 0


        if (!(questList.get(curruntQuesCount).userResponse == 3)) {
            questList.get(curruntQuesCount).userResponse = 1
        }
        setQuestionView(curruntQuesCount)
    }

}