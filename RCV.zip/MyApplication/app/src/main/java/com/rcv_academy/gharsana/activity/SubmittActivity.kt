package com.rcv_academy.gharsana.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.rcv_academy.gharsana.R

class SubmittActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_submitt)
    }
}