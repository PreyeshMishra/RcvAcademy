package com.example.myapplication.adaptor

import android.content.Context
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.ContextCompat

import com.rcv_academy.gharsana.R
import com.rcv_academy.gharsana.model.question.QuestionsList
import de.hdodenhof.circleimageview.CircleImageView
import java.io.File

class VideoGridAdaptor :BaseAdapter{
    lateinit var questionList:List<QuestionsList>
    lateinit var context: Context
    lateinit var inflater: LayoutInflater

    constructor(questionList: List<QuestionsList>, context: Context) : super() {
        this.questionList = questionList
        this.context = context
        inflater = LayoutInflater.from(context)
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var curruntQuestData = questionList.get(p0)
        var myView = inflater.inflate(R.layout.video_grid_item, null)
         var questionNumber:TextView = myView.findViewById(R.id.quest_no_text)
        var circleimage:CircleImageView =  myView.findViewById(R.id.quesStatusCircle)

        questionNumber.text=(p0+1).toString()
        questionNumber.setTextColor(ContextCompat.getColor(context,R.color.colorWhite))
        if (curruntQuestData.userResponse==0){
          //  questionNumber.textColors = ContextCompat.getColor(context,R.color.colorBlack)
            circleimage.background = ContextCompat.getDrawable(context,R.drawable.circle_not_visited)
            questionNumber.setTextColor(ContextCompat.getColor(context,R.color.colorBlack))
        }else if (curruntQuestData.userResponse==1){
            circleimage.background = ContextCompat.getDrawable(context,R.drawable.circle_red)

        }
        else if (curruntQuestData.userResponse==2){
            circleimage.background = ContextCompat.getDrawable(context,R.drawable.circle_green)
        }else if (curruntQuestData.userResponse==3){
            circleimage.background = ContextCompat.getDrawable(context,R.drawable.circle_pink)
        }





        return myView;

    }

    override fun getItem(p0: Int): Any {
     return 0
    }

    override fun getItemId(p0: Int): Long {
      return 0
    }

    override fun getCount(): Int {
       return questionList.size
    }

}