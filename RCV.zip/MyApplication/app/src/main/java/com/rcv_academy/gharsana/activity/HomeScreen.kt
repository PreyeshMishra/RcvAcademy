package com.rcv_academy.gharsana.activity

import android.content.Intent
import android.os.Bundle
import android.widget.AdapterView
import android.widget.GridView
import androidx.appcompat.app.AppCompatActivity
import com.rcv_academy.gharsana.R
import com.rcv_academy.gharsana.adaptor.HomeScreenAdaptor

class HomeScreen : AppCompatActivity(){
    lateinit var gridView: GridView
    var courseList: ArrayList<String> = ArrayList();

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.home_screen)
        courseList.add("RSCIT")
        courseList.add("BSTC")
        courseList.add("REET")
        courseList.add("RAS")
        courseList.add("PATWAR")
        courseList.add("CONSTABLE")
        courseList.add("PTET")
        courseList.add("12th Class")
        courseList.add("10th Class")


        gridView = findViewById(R.id.simpleGridView)

        var homeScreenAdaptor: HomeScreenAdaptor = HomeScreenAdaptor(courseList,this)

        gridView.adapter = homeScreenAdaptor

        gridView.setOnItemClickListener(AdapterView.OnItemClickListener { adapterView, view, i, l ->

            startActivity(Intent(this,InstructionActivity::class.java))
        })
    }
}