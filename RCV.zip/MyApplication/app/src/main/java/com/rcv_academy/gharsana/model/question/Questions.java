package com.rcv_academy.gharsana.model.question;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Questions {

    @SerializedName("durationMinute")
    @Expose
    private String durationMinute;
    @SerializedName("totalQuestions")
    @Expose
    private String totalQuestions;
    @SerializedName("maxMarks")
    @Expose
    private String maxMarks;
    @SerializedName("eachQuesMark")
    @Expose
    private String eachQuesMark;
    @SerializedName("section")
    @Expose
    private String section;
    @SerializedName("sectionDetails")
    @Expose
    private List<SectionDetail> sectionDetails = null;
    @SerializedName("questionsList")
    @Expose
    private List<QuestionsList> questionsList = null;

    public String getDurationMinute() {
        return durationMinute;
    }

    public void setDurationMinute(String durationMinute) {
        this.durationMinute = durationMinute;
    }

    public String getTotalQuestions() {
        return totalQuestions;
    }

    public void setTotalQuestions(String totalQuestions) {
        this.totalQuestions = totalQuestions;
    }

    public String getMaxMarks() {
        return maxMarks;
    }

    public void setMaxMarks(String maxMarks) {
        this.maxMarks = maxMarks;
    }

    public String getEachQuesMark() {
        return eachQuesMark;
    }

    public void setEachQuesMark(String eachQuesMark) {
        this.eachQuesMark = eachQuesMark;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public List<SectionDetail> getSectionDetails() {
        return sectionDetails;
    }

    public void setSectionDetails(List<SectionDetail> sectionDetails) {
        this.sectionDetails = sectionDetails;
    }

    public List<QuestionsList> getQuestionsList() {
        return questionsList;
    }

    public void setQuestionsList(List<QuestionsList> questionsList) {
        this.questionsList = questionsList;
    }

}