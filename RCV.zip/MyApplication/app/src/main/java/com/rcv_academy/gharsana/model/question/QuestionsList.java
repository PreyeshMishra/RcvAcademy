package com.rcv_academy.gharsana.model.question;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class QuestionsList {

    @SerializedName("id")
    @Expose
    private String id;

    public int getAnsweredOption() {
        return answeredOption;
    }

    public void setAnsweredOption(int answeredOption) {
        this.answeredOption = answeredOption;
    }



    public int getQuesStatus() {
        return quesStatus;
    }

    public void setQuesStatus(int quesStatus) {
        this.quesStatus = quesStatus;
    }

    @SerializedName("answeredOption")
    @Expose
    private int answeredOption=0;

    public int getUserResponse() {
        return userResponse;
    }

    public void setUserResponse(int userResponse) {
        this.userResponse = userResponse;
    }

    @SerializedName("quesStatus")
    @Expose
    private int quesStatus;
    @SerializedName("userResponse")
    @Expose
    private int userResponse;
    @SerializedName("section")
    @Expose
    private String section;
    @SerializedName("question")
    @Expose
    private String question;
    @SerializedName("optionsList")
    @Expose
    private List<OptionsList> optionsList = null;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<OptionsList> getOptionsList() {
        return optionsList;
    }

    public void setOptionsList(List<OptionsList> optionsList) {
        this.optionsList = optionsList;
    }

}