package com.rcv_academy.gharsana.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mukesh.OtpView
import com.rcv_academy.gharsana.R

class OtpActivity : AppCompatActivity(){

    lateinit var otpView: OtpView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp)



    }

}