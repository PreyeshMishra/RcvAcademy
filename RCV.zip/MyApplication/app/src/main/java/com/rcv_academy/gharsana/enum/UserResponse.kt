package com.rcv_academy.gharsana.enum

enum class UserResponse {
    REVIEW,
    ANSWERED,
    UNANSWERED,
    NOTVISITED
}